-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th2 22, 2019 lúc 02:17 PM
-- Phiên bản máy phục vụ: 10.1.28-MariaDB
-- Phiên bản PHP: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `mylab`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `be_bought`
--

CREATE TABLE `be_bought` (
  `item_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `be_bought`
--

INSERT INTO `be_bought` (`item_id`, `user_id`, `date`, `quantity`) VALUES
(1, 1, '2019-02-11 04:17:27', 4),
(1, 1, '2019-02-11 04:17:34', 3),
(1, 1, '2019-02-11 04:17:42', 4),
(1, 1, '2019-02-11 04:20:47', 2),
(1, 1, '2019-02-11 04:21:31', 2),
(1, 1, '2019-02-11 04:23:05', 2),
(1, 1, '2019-02-11 04:23:10', 1),
(1, 1, '2019-02-11 04:24:47', 2),
(1, 1, '2019-02-11 04:27:02', 1),
(1, 1, '2019-02-11 05:27:06', 2),
(1, 1, '2019-02-11 05:27:10', 2),
(1, 1, '2019-02-11 05:37:43', 2),
(1, 1, '2019-02-11 05:37:46', 1),
(1, 1, '2019-02-11 05:37:50', 2),
(1, 1, '2019-02-11 05:40:44', 1),
(1, 1, '2019-02-11 05:42:01', 3),
(1, 1, '2019-02-11 05:42:14', 3),
(1, 1, '2019-02-11 05:44:59', 1),
(1, 1, '2019-02-11 05:45:14', 1),
(1, 1, '2019-02-11 12:22:16', 1),
(1, 1, '2019-02-12 03:39:17', 1),
(1, 1, '2019-02-12 03:40:23', 1),
(1, 1, '2019-02-12 03:41:14', 1),
(1, 1, '2019-02-12 04:11:51', 1),
(1, 1, '2019-02-12 14:02:04', 2),
(1, 1, '2019-02-12 14:02:17', 1),
(1, 1, '2019-02-13 05:01:33', 1),
(1, 1, '2019-02-15 02:57:27', 1),
(1, 1, '2019-02-18 02:52:21', 0),
(1, 1, '2019-02-18 02:52:34', 0),
(1, 1, '2019-02-18 02:55:38', 0),
(1, 1, '2019-02-18 03:00:36', 3),
(1, 1, '2019-02-18 04:39:53', 1),
(1, 1, '2019-02-18 04:40:08', 1),
(1, 1, '2019-02-18 04:41:07', 1),
(1, 1, '2019-02-18 04:42:33', 1),
(1, 1, '2019-02-18 04:43:50', 1),
(2, 1, '2019-02-11 04:12:33', 2),
(2, 1, '2019-02-11 04:24:50', 2),
(2, 1, '2019-02-11 04:24:52', 2),
(2, 1, '2019-02-11 04:25:08', 2),
(2, 1, '2019-02-11 05:37:54', 3),
(2, 1, '2019-02-11 05:38:21', 1),
(2, 1, '2019-02-11 05:40:39', 2),
(2, 1, '2019-02-11 05:41:39', 3),
(2, 1, '2019-02-11 05:42:28', 3),
(2, 1, '2019-02-12 03:42:19', 1),
(2, 1, '2019-02-12 03:42:32', 2),
(24, 1, '2019-02-19 13:42:07', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `be_used`
--

CREATE TABLE `be_used` (
  `user_id` int(11) NOT NULL,
  `card_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `be_used`
--

INSERT INTO `be_used` (`user_id`, `card_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `card`
--

CREATE TABLE `card` (
  `id` int(11) NOT NULL,
  `namecard` varchar(255) NOT NULL,
  `seri_number` int(11) NOT NULL,
  `code_number` varchar(13) NOT NULL,
  `value` int(11) NOT NULL,
  `expiry_date` date NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `card`
--

INSERT INTO `card` (`id`, `namecard`, `seri_number`, `code_number`, `value`, `expiry_date`, `used`) VALUES
(1, 'viettel', 123654789, 'a123b456c789', 100000, '2019-09-09', 1),
(2, 'viettel', 123654780, 'a123b456c780', 100000, '2019-09-09', 0),
(3, 'viettel', 123654753, '123a45c5698a', 50000, '2020-01-01', 0),
(4, 'viettel', 159753654, '123a45c5ahr5', 50000, '2020-01-01', 0),
(5, 'viettel', 126549863, '1235acc5ahr5', 50000, '2020-01-01', 0),
(6, 'mobifone', 126545684, '1235ac16scr5', 50000, '2020-01-01', 0),
(7, 'mobifone', 159732568, '15a8cc16scr5', 50000, '2020-01-01', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `shop`
--

CREATE TABLE `shop` (
  `id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `number_of` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `shop`
--

INSERT INTO `shop` (`id`, `item_name`, `image`, `price`, `number_of`) VALUES
(1, 'ÁO', 'http://hstatic.net/640/1000004640/1/2016/8-17/cam-aothun_grande.jpg', 100000, 73),
(2, 'QUẦN', 'https://product.hstatic.net/1000199383/product/quan-kaki-nam-aristino-akk17-01-vang-gacnai.jpg', 200000, 5),
(3, 'DEGREY CULOTTES - DCU', '//product.hstatic.net/1000281824/product/dcu_large.jpg', 250000, 15),
(4, 'CUA SWEATER - CSW', '//product.hstatic.net/1000281824/product/csw_large.jpg', 320000, 30),
(5, 'LEAVE ME OUT HOODIE - LMOD', '//product.hstatic.net/1000281824/product/lmods_8c22b553691846e8a1c09f855b3d08d1_large.png', 380000, 1),
(6, 'THAN BALO - TB', '//product.hstatic.net/1000281824/product/tb_large.jpg', 380000, 19),
(7, 'MED CAP - MC', '//product.hstatic.net/1000281824/product/mcv_0283d49b92b6436d81a3e454331ae1f6_large.jpg', 180000, 24),
(8, 'SHORT BROWNIE WALLET - SBW', '//product.hstatic.net/1000281824/product/sbw_large.jpg', 250000, 7),
(9, 'LONG BROWNIE WALLET - LBW', '//product.hstatic.net/1000281824/product/sbw_a67dd53f16f344859c3a736739510a29_large.jpg', 300000, 24),
(10, 'DADDY PANTS - DAP', '//product.hstatic.net/1000281824/product/dapb_large.jpg', 350000, 16),
(11, 'SAIGON JACKET - SGJ', '//product.hstatic.net/1000281824/product/jacket_large.png', 350000, 9),
(12, 'SAIGON SHIRT - SAS', '//product.hstatic.net/1000281824/product/sasden_large.jpg', 300000, 24),
(13, 'POLO CHEMISE - PC', '//product.hstatic.net/1000281824/product/pc_large.jpg', 280000, 9),
(14, 'DEGREY TURTLENECK - DTK', '//product.hstatic.net/1000281824/product/dtk_large.png', 300000, 16),
(15, 'CIRCLE SWEATER - CIS', '//product.hstatic.net/1000281824/product/cis_large.png', 320000, 20),
(16, 'DEGREY GILE - DGI', '//product.hstatic.net/1000281824/product/dgit_07bca9afde7c4348a459572a476de94d_large.png', 250000, 2),
(17, 'MED BACKPACK - MB', '//product.hstatic.net/1000281824/product/mb_large.png', 380000, 5),
(18, 'DEGREY LOGO CHEMISE - DLC', '//product.hstatic.net/1000281824/product/dlc_8a322783b44b4da59e60b07b122a41f0_large.png', 320000, 12),
(19, 'DEGREY HISTORY SWEATER - DHS', '//product.hstatic.net/1000281824/product/dhsb_a29e9da45e01469daf3153bf99570947_large.jpg', 320000, 22),
(20, 'DEGREY BRA', '//product.hstatic.net/1000281824/product/bra_87fe9931d68a4ee2b3d22c1388118e9e_large.jpg', 220000, 17),
(21, 'Basic Hoodie - BH', '//product.hstatic.net/1000281824/product/bh_large.jpg', 350000, 30),
(22, 'DEGREY BEANIE - DBE', '//product.hstatic.net/1000281824/product/dbe_large.jpg', 180000, 4),
(23, 'DEGREY YUKATA - DY', '//product.hstatic.net/1000281824/product/dy_large.jpg', 380000, 7),
(24, 'DEGREY MÓC KHOÁ 2.0 - MK2', '//product.hstatic.net/1000281824/product/mk2_large.jpg', 50000, 28),
(25, 'DEGREY MASK - DM', '//product.hstatic.net/1000281824/product/dmd_large.jpg', 40000, 4),
(26, 'DG BACKPACK - DB', '//product.hstatic.net/1000281824/product/db_c41fe52d63fa4329aa6ae3b739d4b666_large.jpg', 380000, 30),
(27, 'DEGREY MÓC KHOÁ - MK', '//product.hstatic.net/1000281824/product/mkd_large.jpg', 30000, 25),
(28, 'LOGO TEE - LT', '//product.hstatic.net/1000281824/product/lt_den_large.jpg', 280000, 6),
(29, 'DEGREY ICON TEE - DIT', '//product.hstatic.net/1000281824/product/dit_large.jpg', 320000, 22),
(30, 'RAIN COAT 2.0 - RC2', '//product.hstatic.net/1000281824/product/rc_2.0_large.jpg', 220000, 11),
(31, 'DEGREY SHORT WALLET - DSW', '//product.hstatic.net/1000281824/product/79_0252349fee9442f6a3660e468ed83fb8_large.jpg', 240000, 10),
(32, 'BALO BOX - BB', '//product.hstatic.net/1000281824/product/bb1_large.jpg', 400000, 26),
(33, 'DEGREY DUNGAREE - DD', '//product.hstatic.net/1000281824/product/74_large.jpg', 390000, 27),
(34, 'ADVENTURE TIME TSHIRT - ATT FINN', '//product.hstatic.net/1000281824/product/29_large.jpg', 280000, 30),
(35, 'ADVENTURE TIME TSHIRT - ATT', '//product.hstatic.net/1000281824/product/31_56f6b732d72949709816e7be8dbeb85f_large.jpg', 280000, 2),
(36, 'DEGREY BOXER - DGB', '//product.hstatic.net/1000281824/product/boxer_large.jpg', 100000, 16),
(37, 'DEGREY CAP - DRC', '//product.hstatic.net/1000281824/product/3_5afeb372daee464eadbc8062870f39c9_large.jpg', 180000, 14),
(38, 'BOX PANTS', '//product.hstatic.net/1000281824/product/box_pants_large.jpg', 520000, 4),
(39, 'GOLD JACKET - GJ', '//product.hstatic.net/1000281824/product/12_5b4f574a1cd64744b2b827fa2d8e1950_large.jpg', 420000, 9),
(40, 'JINBEI', '//product.hstatic.net/1000281824/product/14_48b25d7e0ddd4085b90de8e8392edfad_large.jpg', 380000, 13);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'OK',
  `gioitinh` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ngaysinh` date NOT NULL,
  `diachi` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '1',
  `vip_expire` date NOT NULL,
  `coin` int(11) NOT NULL,
  `remember_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `name`, `status`, `gioitinh`, `ngaysinh`, `diachi`, `email`, `avatar`, `level`, `vip_expire`, `coin`, `remember_token`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Hòa Nguyễn', 'OK', 'Male', '2019-01-30', 'Hiệp Hòa, Bắc Giang', 'hoanguyenduc0304@gmail.com', './avatar/avatar1.jpg', 2, '2019-06-11', 65000, ''),
(2, 'hoa1', 'e034fb6b66aacc1d48f445ddfb08da98', 'Hòa', 'OK', 'Male', '2019-02-05', 'bac giang', 'abc@fpt.edu.vn', './avatar/avatar2.jpg', 1, '0000-00-00', 50000, NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `be_bought`
--
ALTER TABLE `be_bought`
  ADD PRIMARY KEY (`item_id`,`user_id`,`date`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Chỉ mục cho bảng `be_used`
--
ALTER TABLE `be_used`
  ADD PRIMARY KEY (`user_id`,`card_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `card_id` (`card_id`);

--
-- Chỉ mục cho bảng `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `card`
--
ALTER TABLE `card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `shop`
--
ALTER TABLE `shop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT cho bảng `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `be_bought`
--
ALTER TABLE `be_bought`
  ADD CONSTRAINT `be_bought_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `shop` (`id`),
  ADD CONSTRAINT `be_bought_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Các ràng buộc cho bảng `be_used`
--
ALTER TABLE `be_used`
  ADD CONSTRAINT `FK_beused_card` FOREIGN KEY (`card_id`) REFERENCES `card` (`id`),
  ADD CONSTRAINT `FK_beused_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
